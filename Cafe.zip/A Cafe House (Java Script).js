// 🌿 Smooth Coffee Website JavaScript Effects 🌿

// fade-in effect
const sections = document.querySelectorAll('section');
const appearOptions = { threshold: 0.15 };

if ('IntersectionObserver' in window) {
  const appearOnScroll = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('fade-in');
        observer.unobserve(entry.target);
      }
    });
  }, appearOptions);

  sections.forEach(sec => appearOnScroll.observe(sec));
} else {
  sections.forEach(sec => sec.classList.add('fade-in'));
}

// typing effect in hero section
const heroText = document.querySelector('.hero h1');
if (heroText) {
  const text = heroText.textContent.trim();
  heroText.textContent = '';
  let index = 0;
  function typeWriter() {
    if (index < text.length) {
      heroText.textContent += text.charAt(index);
      index++;
      setTimeout(typeWriter, 100);
    } else {
      heroText.classList.add('typed-done');
    }
  }
  setTimeout(typeWriter, 500);
}

// button hover glow effect
document.querySelectorAll('button').forEach(btn => {
  btn.addEventListener('mouseenter', () => {
    btn.style.boxShadow = '0 0 20px rgba(255,179,71,0.6)';
  });
  btn.addEventListener('mouseleave', () => {
    btn.style.boxShadow = 'none';
  });
});
